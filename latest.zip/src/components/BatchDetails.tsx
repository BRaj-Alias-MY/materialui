import React from 'react'
import '../App.css';
import { Layout, FABButton, Icon, DataTable, TableHeader, Grid, Cell } from 'react-mdl';
import { connect } from 'react-redux';
import { fetchGrn } from '../redux/actions/grnActions';



class BatchDetails extends React.Component<any, any> {
    render() {
        return (
            <React.Fragment>
                <div className="demo-inner-content padding-top-inner">
                    <Layout>
                        <div>
                            <span className="span-style">GRN - Batch Details</span>
                            <span className="span-right">
                                <FABButton colored ripple className="cursor">
                                    <Icon name="add" />
                                </FABButton>
                            </span>
                        </div>
                    </Layout>
                </div>


                <div style={{ width: '80%', margin: 'auto' }}>
                    <Grid className="demo-grid-ruler">

                    </Grid>
                </div>
                <div className="content-div">
                    <Grid className="demo-grid">
                        <Cell col={12}>
                            <DataTable
                                shadow={0}
                                rows={[
                                    { material: 'Acrylic (Transparent)', quantity: 25, price: 2.90 },
                                    { material: 'Plywood (Birch)', quantity: 50, price: 1.25 },
                                    { material: 'Laminate (Gold on Blue)', quantity: 10, price: 2.35 }
                                ]}
                            >
                                <TableHeader name="material" tooltip="The amazing material name">Material</TableHeader>
                                <TableHeader numeric name="quantity" tooltip="Number of materials">Quantity</TableHeader>
                                <TableHeader numeric name="price" cellFormatter={(price) => `\$${price.toFixed(2)}`} tooltip="Price pet unit">Price</TableHeader>
                            </DataTable>
                        </Cell>

                    </Grid>
                </div>
            </React.Fragment>


        )
    }
}
const mapStateToProps = (state: any) => ({

    batchInfo: state.grns.batchInfo,
});

export default connect(mapStateToProps, { fetchGrn })(BatchDetails);