import { FETCH_GRN } from './types';
import axios from 'axios';

export const fetchGrn = () => (dispatch: any) => {
    axios.get('http://localhost:8000/grn/all')
        .then(response => {
            console.log(response.data)
            dispatch({
                type: FETCH_GRN,
                payload: response,
            })
        }
        ).catch(err => console.log(err))

};
