import { FETCH_GRN } from '../actions/types';

const intialState = {
    batchInfo: [],

};

export default function (state = intialState, action: any) {
    switch (action.type) {

        case FETCH_GRN:
            return {
                ...state,
                batchInfo: action.payload,
            };

        default:
            return state;
    }
}
