import { combineReducers } from 'redux';
import grnReducer from './grnReducer';

export default combineReducers({
    grns: grnReducer,

});
