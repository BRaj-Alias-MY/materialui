import React from 'react'
import '../App.css';
import { Layout, FABButton, Icon,  TableHeader, Grid, Cell, Dialog,DialogActions,DialogContent,DialogTitle } from 'react-mdl';
import { connect } from 'react-redux';
import { fetchGrn } from '../redux/actions/grnActions';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import {InputText} from 'primereact/inputtext';
import axios from "axios";








class BatchDetails extends React.Component<any, any> {
    constructor(props: any) {
        super(props)
    
        this.state = { po_no: '', batch_no : '' };
        this.actionTemplate = this.actionTemplate.bind(this);
        this.onSub = this.onSub.bind(this);
        this.handleOpenDialog = this.handleOpenDialog.bind(this);
    this.handleCloseDialog = this.handleCloseDialog.bind(this);
      
      }

      handleOpenDialog() {
        this.setState({
          openDialog: true
        });
      }
    
      handleCloseDialog() {
        this.setState({
          openDialog: false
        });
      }
      



   public handleNameChange = (e: any) => {
    //  this.setState({po: e.target.value});
    e.preventDefault()
    this.setState({ [e.target.name]: e.target.value } as any )
      console.log(this.state);
   };
   
   public handleSubmit = (e:any) =>{
     e.preventDefault();
     const data = { ... this.state }
     console.log(data);
     axios.post('http://localhost:8000/batch/savebatchlotdata',data).then(response=>{
    console.log(response);
    
 });
    
   
   }
   
    
      public onSub(selectedColumn: any) {
        console.log(selectedColumn);
        const poNumber = selectedColumn.rowData.po_no;
        const batchNumber = selectedColumn.rowData.id;
        this.props.history.push(`/grndetails/${poNumber}/${batchNumber}`);
      }
      public actionTemplate(rowData: any, column: any) {
    
        return (
          < div >
            <Button onClick={(e) => this.onSub(column)} type="button" icon="pi pi-search" className="p-button-success" />
            
          </div >
        );
      }
    
    
      public componentWillMount() {
        this.props.fetchGrn();
      }
    render() {
        const paginatorLeft = <Button icon="pi pi-refresh" />;
        const paginatorRight = <Button icon="pi pi-cloud-upload" />;
        return (

            <React.Fragment>
                <div>
        <Dialog open={this.state.openDialog}>
          <DialogTitle>Add PO</DialogTitle>
          <DialogContent>
          <form onSubmit={this.handleSubmit}>
      <div>
        <div className="form-group">
        <label htmlFor="po">PO :</label>
      <span className="p-float-label">
<InputText id="po" className='form-control' name='po_no' value={this.state.po_no}   onChange={this.handleNameChange}/>
</span>
</div>
<div className="form-group">
<label htmlFor="in">Batch :</label>
<span className="p-float-label">
<InputText id="batch" className='form-control' name='batch_no' value={this.state.batch_no}  onChange={this.handleNameChange}/>
 </span>   
 </div>

  <button className="btn btn-primary">Submit Data</button>

   </div>
 </form>
          </DialogContent>
          <DialogActions>
            <Button type='button' onClick={this.handleCloseDialog}>Disagree</Button>
          </DialogActions>
        </Dialog>  
</div>
                <div className="demo-inner-content padding-top-inner">
                    <Layout>
                        <div>
                            <span className="span-style">GRN - Batch Details</span>
                            <span className="span-right">
                                <FABButton colored ripple className="cursor" onClick={this.handleOpenDialog}  >
                                    <Icon name="add" />
                                </FABButton>
                            </span>
                        </div>
                    </Layout>
                </div>


                <div style={{ width: '80%', margin: 'auto' }}>
                    <Grid className="demo-grid-ruler">

                    </Grid>
                </div>
                <div className="content-div">
                    <Grid className="demo-grid">
                        <Cell col={12}>
                            <DataTable value={this.props.batchInfo.data} paginator={true} paginatorLeft={paginatorLeft} paginatorRight={paginatorRight} rows={10} rowsPerPageOptions={[5, 10, 20]}>
                            <Column field="po_no" header="PO Number" />
                            <Column field="batch_no" header="Batch Number" />
                            <Column field="batch_qty" header="Quantity" />
                            <Column header="Action" body={this.actionTemplate} style={{ textAlign: 'center', width: '6em' }} />
                            </DataTable>                                                                        
                        </Cell>

                    </Grid>
                </div>
               
            </React.Fragment>



        )
    }
}
const mapStateToProps = (state: any) => ({

    batchInfo: state.grns.batchInfo,
});

export default connect(mapStateToProps, { fetchGrn })(BatchDetails);