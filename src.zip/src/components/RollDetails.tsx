import React from 'react'
import '../App.css';
import { Layout, Grid, Cell, Card } from 'react-mdl';

export default class RollDetails extends React.Component {
  render() {
    return (
      <React.Fragment>
        <div className="demo-inner-content padding-top-inner">
          <Layout>
            <div>
              <span className="span-style">GRN - Batch Details</span>

            </div>
          </Layout>
        </div>


        <div style={{ width: '80%', margin: 'auto' }}>
          <Grid className="demo-grid-ruler">

          </Grid>
        </div>
        <div className="content-div">
          <Grid className="demo-grid">
            <Cell col={12}>
              <Card shadow={0} className="card ">
                <div className="inner-content">
                  ti card area
                  </div>
              </Card>
            </Cell>

          </Grid>
        </div>
      </React.Fragment>


    )
  }
}
