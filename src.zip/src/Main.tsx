import React from 'react';
import { Layout, Header, Navigation, Drawer, Content, Icon, Badge, ListItem, ListItemContent } from 'react-mdl';
import './App.css';
import { Route, NavLink, BrowserRouter, Switch } from 'react-router-dom';
import BatchDetails from './components/BatchDetails';
import RollDetails from './components/RollDetails';
import $ from 'jquery';

export default class Main extends React.Component {
    constructor(props: any) {
        super(props)

        this.state = {
            drawer: false
        }
    }
    componentDidMount() {
        // $('.cursor').click(function () {
        //     //alert('hi')
        //     $('.mdl-layout__obfuscator').trigger('click');
        // })
    }

    render() {

        return (
            <BrowserRouter>
                <React.Fragment>

                    <div className="demo-big-content">
                        <Layout>
                            <Header title="SFCS 2.0" scroll>
                                <Navigation>
                                    <a href="#">
                                        <Badge text="1" overlap>
                                            <Icon name="account_box" />
                                        </Badge>
                                    </a>

                                    <a href="#">
                                        <Badge text="3" overlap>
                                            <Icon name="account_box" />
                                        </Badge>
                                    </  a>

                                </Navigation>
                            </Header>
                            <Drawer title="Main Menu">
                                <Navigation>
                                    <NavLink className="cursor" to="/">
                                        <ListItem>
                                            <ListItemContent avatar="assignment">Dashboard</ListItemContent>

                                        </ListItem>
                                    </NavLink>

                                    <NavLink className="cursor" to="/batchdetails">
                                        <ListItem>
                                            <ListItemContent avatar="account_circle">Batch Details</ListItemContent>

                                        </ListItem>
                                    </NavLink>
                                    <NavLink className="cursor" to="/rollinfo">
                                        <ListItem>
                                            <ListItemContent avatar="person">Inspection</ListItemContent>

                                        </ListItem>
                                    </NavLink>

                                </Navigation>
                            </Drawer>
                            <Content>
                                <div className="page-content">
                                    <Switch>
                                        <Route exact path="/" component={BatchDetails} />
                                        <Route path="/batchdetails" component={BatchDetails} />
                                        <Route path="/rollinfo" component={RollDetails} />

                                        <Route component={BatchDetails} />
                                    </Switch>
                                </div>
                            </Content>
                        </Layout>

                    </div>

                </React.Fragment>
            </BrowserRouter>

        )
    }
}
